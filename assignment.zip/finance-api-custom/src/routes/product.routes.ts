import expesss from 'express';
import {
  createRecordsController,
  getAllRecordsController,
} from '../controller/records.controller';

import { checkToken } from '../middleware/access-token';
import { createRecordsSchema, validateData } from '../middleware/validation';
import upload from '../middleware/upload';

const router = expesss.Router();

router.get('/', checkToken, getAllRecordsController);
router.post(
  '/',
  checkToken,
  upload,
  validateData(createRecordsSchema),
  createRecordsController
);

export default router;
