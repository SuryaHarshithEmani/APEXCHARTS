/*
  Warnings:

  - You are about to alter the column `price` on the `Records` table. The data in that column could be lost. The data in that column will be cast from `Decimal` to `Int`.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Records" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "price" INTEGER NOT NULL,
    "image" TEXT NOT NULL,
    "stock" INTEGER NOT NULL,
    "category" TEXT NOT NULL DEFAULT 'COFFEE'
);
INSERT INTO "new_Records" ("category", "description", "id", "image", "name", "price", "stock") SELECT "category", "description", "id", "image", "name", "price", "stock" FROM "Records";
DROP TABLE "Records";
ALTER TABLE "new_Records" RENAME TO "Records";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
