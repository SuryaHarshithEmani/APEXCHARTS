-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Records" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "price" DECIMAL NOT NULL,
    "image" TEXT NOT NULL,
    "stock" INTEGER NOT NULL,
    "user_id" TEXT NOT NULL,
    "category" TEXT NOT NULL DEFAULT 'COFFEE'
);
INSERT INTO "new_Records" ("category", "description", "id", "image", "name", "price", "stock", "user_id") SELECT "category", "description", "id", "image", "name", "price", "stock", "user_id" FROM "Records";
DROP TABLE "Records";
ALTER TABLE "new_Records" RENAME TO "Records";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
